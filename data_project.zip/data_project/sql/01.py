import mysql.connector 
import csv

mydb = mysql.connector.connect(
	host = '127.0.0.1',
    port = 3306,
	user = 'root',
    password = 'MyNewPass',
    database = 'music'
)

cursor = mydb.cursor()

with open('./music_data/music_store_data/artist.csv', 'r') as f:
    reader = csv.reader(f)
    for row in reader:
        insert_stmt = ("INSERT INTO artist VALUES (%d, %s)")
        data = (row[0], row[1])
        cursor.execute(insert_stmt, data)
