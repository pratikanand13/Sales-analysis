#include <bits/stdc++.h>
using namespace std;
int depthFirst(vector<vector<int>> matrix)
{

    int n = matrix.size();
    int m = matrix[0].size();
    if (matrix[n - 1][m - 1] == 1 || matrix[0][0] == 1)
    {
        return -1;
    }
    queue<pair<int, int>> queue;
    matrix[n - 1][m - 1] = 1;
    queue.push({n - 1, m - 1});

    int oldX[4] = {0, 1, 0, -1};
    int oldY[4] = {1, 0, -1, 0};

    while (!queue.empty())
    {
        int i = queue.front().first;
        int j = queue.front().second;
        queue.pop();
        if (i == 0 && j == 0)
        {
            return matrix[0][0];
        }
        for (int k = 0; k < 4; k++)
        {
            int newX = i + oldX[k];
            int newY = j + oldY[k];

            if (newX >= 0 && newY >= 0 && newX < n && newY < m && matrix[newX][newY] == 0)
            {
                matrix[newX][newY] = 1 + matrix[i][j];
                queue.push({newX, newY});
                if (newX == 0 && newY == 0)
                {
                    return matrix[newX][newY];
                }
            }
        }
    }

    return -1;
}
int main()
{

    int n, m;
    cin >> n >> m;
    vector<vector<int>> input(n, vector<int>(m, 0));
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> input[i][j];
        }
    }
    int ans = -1;
    ans = max(ans, depthFirst(input));
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if (input[i][j] == 0)
            {
                input[i][j] = 1;
                ans = max(ans, depthFirst(input));
                input[i][j] = 0;
            }
        }
    }
    cout << ans;
}