#include <iostream>
#include<bits/stdc++.h>
#include <vector>
#include <cmath>
#include <unordered_map>
#include <stack>
#include <iomanip>

using namespace std;

bool areGearsConnected(const vector<int>& gear1, const vector<int>& gear2) {
    int x1 = gear1[0], y1 = gear1[1], r1 = gear1[2];
    int x2 = gear2[0], y2 = gear2[1], r2 = gear2[2];

    // Calculate the distance between gear centers
    double distance = sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));

    // Check if the circles touch externally
    return distance == (r1 + r2);
}

double rotateGears(const vector<vector<int>>& gearDetails) {
    int n = gearDetails.size();

    // Create a graph to represent the connections between gears
    unordered_map<int, vector<int>> graph;
    for (int i = 0; i < n - 1; ++i) {
        for (int j = i + 1; j < n; ++j) {
            // Check if the gears are connected
            if (areGearsConnected(gearDetails[i], gearDetails[j])) {
                graph[i].push_back(j);
                graph[j].push_back(i);
            }
        }
    }

    // Check if Gear 1 and Gear N are connected to exactly one gear
    if (graph[0].size() != 1 || graph[n - 1].size() != 1) {
        return -1.0; // Could Not Process
    }

    // Initialize memoization table
    map<pair<int, int>, double> memo;
    for (int i = 0; i < n; ++i) {
        memo[{i, n - 1}] = 1.0;
    }

    // Perform rotation calculations using an iterative DFS approach with a stack
    stack<pair<int, int>> s;
    s.push({0, n - 1});
    while (!s.empty()) {
        int current = s.top().first;
        int end = s.top().second;
        s.pop();

        // If the current gear has already been calculated, skip it
        if (memo.find({current, end}) != memo.end()) {
            continue;
        }

        // Initialize max rotation count to None
        double maxRotationCount = -1.0;

        // Iterate through connected gears
        for (int neighbor : graph[current]) {
            // If the neighbor gear has not been calculated, add it to the stack
            if (memo.find({neighbor, end}) == memo.end()) {
                s.push({neighbor, end});
            }

            // Calculate the next rotation count
            double nextRotation = memo[{neighbor, end}];
            if (nextRotation != -1.0) {
                nextRotation *= gearDetails[current][2] / gearDetails[neighbor][2];

                // Update max rotation count
                if (maxRotationCount == -1.0 || nextRotation > maxRotationCount) {
                    maxRotationCount = nextRotation;
                }
            }
        }

        // Memoize the result
        memo[{current, end}] = maxRotationCount;
    }

    double result = memo[{0, n - 1}];
    return (result != -1.0) ? result : -1.0; // Could Not Process
}

int main() {
    int N;
    cin >> N;

    vector<vector<int>> gearDetails;
    for (int i = 0; i < N; ++i) {
        int x, y, r;
        cin >> x >> y >> r;
        gearDetails.push_back({x, y, r});
    }

    double result = rotateGears(gearDetails);
    if (result != -1.0) {
        cout << fixed << setprecision(2) << result << endl;
    } else {
        cout << "Could Not Process" << endl;
    }

    return 0;
}
